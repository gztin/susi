// JavaScript Document
$(function(){
	$("#li_welcome").click(function(){
		$("html,body").animate({scrollTop:0},800);
		return false;
	});

	$(".goto-News").click(function(){
		$("html,body").animate({scrollTop:1100},800);
		return false;
	});
	$("#li_news").click(function(){
		$("html,body").animate({scrollTop:1100},800);
		return false;
	});


	$("#li_about").click(function(){
		$("html,body").animate({scrollTop:2250},800);
		return false;
	});
	$(".goto-About").click(function(){
		$("html,body").animate({scrollTop:2250},800);
		return false;
	});

	$("#li_gallery").click(function(){
		$("html,body").animate({scrollTop:3300},800);
		return false;
	});
	$(".goto-Gallery").click(function(){
		$("html,body").animate({scrollTop:3300},800);
		return false;
	});

	$("#li_dishes").click(function(){
		$("html,body").animate({scrollTop:4350},800);
		return false;
	});
	$(".goto-Dishes").click(function(){
		$("html,body").animate({scrollTop:4350},800);
		return false;
	});

	$("#li_service").click(function(){
		$("html,body").animate({scrollTop:5550},800);
		return false;
	});
	$(".goto-Service").click(function(){
		$("html,body").animate({scrollTop:5550},800);
		return false;
	});

	$("#li_location").click(function(){
		$("html,body").animate({scrollTop:6550},800);
		return false;
	});
	$(".goto-Location").click(function(){
		$("html,body").animate({scrollTop:6550},800);
		return false;
	});
});